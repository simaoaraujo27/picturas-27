// Future end-to-end coverage for video processing.
