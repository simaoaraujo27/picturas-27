// Future end-to-end coverage for image processing.
