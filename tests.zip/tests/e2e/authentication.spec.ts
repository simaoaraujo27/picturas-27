// Future end-to-end coverage for authentication.
