# Infraestrutura de testes

Esta estrutura prepara três ferramentas, sem acrescentar casos de teste: **Pytest** para Python, **Jest + Supertest** para APIs Node.js e **Playwright** para a interface web. Os testes preexistentes são preservados: `Tools/video/tests/` usa Pytest e `projects/tests/` usa `node:test` (não é uma suite Jest).

## Organização

| Diretório | Uso |
|---|---|
| `tests/python/unit/` | Futuros testes unitários Python |
| `tests/python/integration/` | Futuros testes de integração Python |
| `tests/api/{auth,projects,uploads,processing}/` | Futuros `*.test.js` com Jest + Supertest |
| `tests/e2e/` | Futuros `*.spec.ts` Playwright; os ficheiros atuais têm apenas comentários |
| `tests/fixtures/` | Imagens e vídeos de teste a adicionar quando forem necessários |
| `tests/reports/` | JUnit XML, HTML, screenshots e traces gerados; conteúdo ignorado pelo Git |

## Instalação

Os serviços Python usam principalmente Python **3.11** nas imagens Docker; `Tools/expand_ai` usa **3.10**. Para testes locais, criar um ambiente Python compatível e instalar as dependências do worker existente:

```bash
python3.11 -m venv .venv
.venv/bin/pip install -r tests/requirements-python.txt -r Tools/video/requirements-dev.txt
```

Os serviços Node.js têm `package.json` independentes. As dependências de Jest, Supertest, `jest-junit` e Playwright ficam no `package.json` da **raiz** para evitar alterações nos serviços:

```bash
npm install --no-package-lock
npx playwright install chromium
```

Não é preciso iniciar Docker para verificar a configuração. Testes E2E futuros precisarão da aplicação em execução (`docker compose up -d --build`); a URL é configurável com `PLAYWRIGHT_BASE_URL` e o valor predefinido é `https://localhost:8080`. Não é iniciado nenhum servidor pelo Playwright.

## Execução

```bash
make test              # Pytest, Jest/Supertest e Playwright
make test-python       # Pytest: tests/python e Tools/video/tests existentes
make test-api          # Jest/Supertest: tests/api
make test-e2e          # Playwright: tests/e2e
make test-unit         # Pytest: tests/python/unit
make test-integration  # Pytest: tests/python/integration
make test-strict       # Todas; suites vazias ou ferramentas em falta falham
```

Os mesmos modos estão disponíveis em `./scripts/run-tests.sh [all|python|api|e2e|unit|integration] [--strict]`. O runner executa as suites selecionadas por ordem, mesmo que alguma falhe, e termina com erro perante uma falha real. No modo normal, suites vazias ou indisponíveis não produzem erro global; no modo estrito produzem.

**Estados:** `PASSED` significa que os testes executados terminaram com êxito; `FAILED` indica erro real; `NO TESTS` indica que não há casos descobertos; `UNAVAILABLE` indica que a ferramenta local necessária não está instalada. `NO TESTS` e `UNAVAILABLE` nunca contam como testes aprovados.

Pytest escreve `tests/reports/pytest-<suite>.xml`; Jest escreve `tests/reports/jest-junit.xml`; Playwright escreve HTML em `tests/reports/playwright-html/` e artefactos de falha em `tests/reports/playwright-results/`.

## Próximos passos

Adicionar casos de teste reais. Para API, os serviços Express poderão exigir configuração de dependências externas ou um modo de importar a aplicação sem iniciar o listener; isso será avaliado quando houver casos concretos. Não se refatorizaram serviços nesta fase. Os testes Node existentes em `projects/tests/` podem ser executados separadamente com `node --test projects/tests/*.test.js` até se decidir se devem integrar o runner ou migrar para Jest.

## Registo da atividade

**2026-11-04, 15:20 WET · commit de partida `0523102`.** Analisados `AGENTS.md`, Compose, Dockerfiles, gestores de dependências e testes preexistentes. Criados os diretórios, configurações e comandos acima, sem alterar lógica da aplicação nem adicionar casos. `bash -n`, `node --check jest.config.cjs`, leitura JSON de `package.json` e `make -n` passaram. O runner normal identificou Python como `UNAVAILABLE` (Pytest não instalado neste ambiente) e API/E2E como `NO TESTS`; o modo estrito terminou com código 1 e um argumento inválido com código 2. Não foram validadas execuções Jest/Playwright porque as dependências ainda não estão instaladas. Estado Git: novos ficheiros de testes/configuração, `.gitignore` e `package.json` alterados; `docs/` já era trabalho anterior não relacionado.
