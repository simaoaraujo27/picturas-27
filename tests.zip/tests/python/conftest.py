# Shared fixtures for future Python tests.
