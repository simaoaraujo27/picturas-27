"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Download, FileVideo, MoreVertical, Scissors, Trash } from "lucide-react";
import { TrimVideoDialog } from "./trim-video-dialog";
import { RemoveSegmentVideoDialog } from "./remove-segment-video-dialog";
import type { ProjectVideo } from "@/lib/projects";
import { useCanEditProject, useProjectInfo } from "@/providers/project-provider";
import { useSession } from "@/providers/session-provider";
import { useDeleteProjectVideo, useDownloadProjectVideo } from "@/lib/mutations/projects";
import { useToast } from "@/hooks/use-toast";
import { getErrorMessage } from "@/lib/error-messages";
import { api } from "@/lib/axios";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Progress } from "@/components/ui/progress";
import { HardDrive } from "lucide-react";

export function VideoStorageUsage({ videoCount }: { videoCount: number }) {
  const { _id: pid } = useProjectInfo();
  const session = useSession();
  const search = useSearchParams();
  const ownerId = search.get("owner") ?? session.user._id;
  const shareId = search.get("share");
  const [usage, setUsage] = useState<{ used: number; limit: number }>();

  useEffect(() => {
    let current = true;
    api
      .get(`/projects/${ownerId}/${pid}/video/storage${shareId ? `?share=${encodeURIComponent(shareId)}` : ""}`, {
        headers: { Authorization: `Bearer ${session.token}` },
      })
      .then((response) => {
        if (current) setUsage(response.data);
      })
      .catch(() => {});
    return () => {
      current = false;
    };
  }, [ownerId, pid, shareId, session.token, videoCount]);

  if (!usage) return null;
  const pct = Math.min(100, Math.max(0, (usage.used / usage.limit) * 100));
  return (
    <div className="mb-1 text-xs text-muted-foreground flex items-center gap-3 bg-card/80 border rounded-md px-3.5 py-2 w-fit shadow-sm">
      <HardDrive className="size-3.5 text-primary shrink-0" />
      <span className="shrink-0">
        Video storage: <strong className="text-foreground">{(usage.used / 1_000_000).toFixed(1)} MB</strong> / {(usage.limit / 1_000_000).toFixed(0)} MB ({pct.toFixed(1)}%)
      </span>
      <Progress className="h-1.5 w-28 bg-muted shrink-0" value={pct} />
    </div>
  );
}

interface ProjectVideoListProps {
  videos: ProjectVideo[];
  selectedVideoId?: string;
  onSelectVideo?: (video: ProjectVideo) => void;
  onTrimVideo?: (video: ProjectVideo) => void;
}

export function ProjectVideoList({
  videos,
  selectedVideoId,
  onSelectVideo,
  onTrimVideo,
}: ProjectVideoListProps) {
  if (!videos.length) return null;
  return (
    <section aria-label="Project videos" className="border-t px-4 py-3 bg-card/60 backdrop-blur-sm shrink-0">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-sm font-semibold flex items-center gap-1.5">
          <FileVideo className="size-4 text-primary" />
          Project Videos ({videos.length})
        </h2>
        <span className="text-xs text-muted-foreground">
          Click a video to preview and edit in the central monitor
        </span>
      </div>
      <ul className="flex flex-wrap gap-2">
        {videos.map((video) => (
          <ProjectVideoItem
            key={video.id}
            video={video}
            isSelected={video.id === selectedVideoId}
            onSelect={() => onSelectVideo?.(video)}
            onTrim={() => onTrimVideo?.(video)}
          />
        ))}
      </ul>
    </section>
  );
}

export function ProjectVideoItem({
  video,
  isSelected,
  large = false,
  onSelect,
  onTrim,
}: {
  video: ProjectVideo;
  isSelected?: boolean;
  large?: boolean;
  onSelect?: () => void;
  onTrim?: () => void;
}) {
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [trimOpen, setTrimOpen] = useState(false);
  const [removeSegmentOpen, setRemoveSegmentOpen] = useState(false);
  const [playbackUrl, setPlaybackUrl] = useState<string>();

  const { _id: pid, version } = useProjectInfo();
  const canEdit = useCanEditProject();
  const session = useSession();
  const search = useSearchParams();
  const ownerId = search.get("owner") ?? session.user._id;
  const shareId = search.get("share") ?? undefined;
  const deleteVideo = useDeleteProjectVideo(session.user._id, pid, session.token, ownerId, shareId);
  const downloadVideo = useDownloadProjectVideo();
  const { toast } = useToast();

  useEffect(() => {
    let current = true;
    api
      .get<{ url: string }>(
        `/projects/${ownerId}/${pid}/video/${video.id}/playback${shareId ? `?share=${encodeURIComponent(shareId)}` : ""}`,
        { headers: { Authorization: `Bearer ${session.token}` } }
      )
      .then((response) => {
        if (current) setPlaybackUrl(response.data.url);
      })
      .catch(() => {
        if (current) setPlaybackUrl(undefined);
      });
    return () => {
      current = false;
    };
  }, [ownerId, pid, video.id, shareId, session.token]);

  async function confirmDelete() {
    try {
      await deleteVideo.mutateAsync({ videoId: video.id, projectVersion: version });
      setConfirmOpen(false);
      toast({ title: `Video ${video.name} deleted successfully.` });
    } catch (error) {
      const { title, description } = getErrorMessage("video-delete", error);
      toast({ title, description, variant: "destructive" });
    }
  }

  async function download() {
    try {
      await downloadVideo.mutateAsync({
        uid: session.user._id,
        pid,
        videoId: video.id,
        name: video.name,
        token: session.token,
        ownerId,
        shareId,
      });
      toast({ title: `Video ${video.name} downloaded successfully.` });
    } catch (error) {
      const { title, description } = getErrorMessage("video-download", error);
      toast({ title, description, variant: "destructive" });
    }
  }

  function handleTrimClick() {
    if (onTrim) {
      onTrim();
    } else {
      setTrimOpen(true);
    }
  }

  if (large) {
    return (
      <div className="relative flex h-full min-h-0 flex-col overflow-hidden rounded-lg border bg-background">
        <div className="flex min-h-0 flex-1 items-center justify-center bg-black">
          {playbackUrl ? (
            <video
              key={playbackUrl}
              src={playbackUrl}
              controls
              playsInline
              preload="metadata"
              className="max-h-full max-w-full"
              aria-label={video.name}
            />
          ) : (
            <FileVideo className="size-12 text-muted-foreground" />
          )}
        </div>
        <div className="flex items-center gap-2 px-3 py-2">
          <span className="min-w-0 flex-1 truncate text-sm" title={video.name}>
            {video.name}
          </span>
          {video.duration != null && <span className="shrink-0 text-xs">{video.duration.toFixed(1)} s</span>}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="size-7 shrink-0" aria-label={`Options for ${video.name}`}>
                <MoreVertical className="size-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start">
              {canEdit && (
                <DropdownMenuItem className="flex justify-between" onSelect={handleTrimClick}>
                  <span>Trim Video</span>
                  <Scissors className="size-4" />
                </DropdownMenuItem>
              )}
              {canEdit && (
                <DropdownMenuItem className="flex justify-between" onSelect={() => setRemoveSegmentOpen(true)}>
                  <span>Remove Segment</span>
                  <Scissors className="size-4 text-destructive" />
                </DropdownMenuItem>
              )}
              {canEdit && (
                <DropdownMenuItem className="flex justify-between text-destructive" onSelect={() => setConfirmOpen(true)}>
                  <span>Delete</span>
                  <Trash className="size-4" />
                </DropdownMenuItem>
              )}
              <DropdownMenuItem className="flex justify-between" disabled={downloadVideo.isPending} onSelect={download}>
                <span>Download</span>
                <Download className="size-4" />
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        <Dialog
          open={confirmOpen}
          onOpenChange={(next) => {
            if (!deleteVideo.isPending) setConfirmOpen(next);
          }}
        >
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Are you sure?</DialogTitle>
              <DialogDescription>This action cannot be undone.</DialogDescription>
            </DialogHeader>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setConfirmOpen(false)}>
                Cancel
              </Button>
              <Button variant="destructive" disabled={deleteVideo.isPending} onClick={confirmDelete}>
                {deleteVideo.isPending ? "Deleting..." : "Permanently Delete"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
        <TrimVideoDialog
          open={trimOpen}
          onOpenChange={setTrimOpen}
          video={video}
          ownerId={ownerId}
          projectId={pid}
          token={session.token}
          shareId={shareId}
          allowFast={session.user.type === "premium"}
        />
        <RemoveSegmentVideoDialog
          open={removeSegmentOpen}
          onOpenChange={setRemoveSegmentOpen}
          video={video}
          ownerId={ownerId}
          projectId={pid}
          projectVersion={version}
          token={session.token}
          shareId={shareId}
        />
      </div>
    );
  }

  return (
    <li className="max-w-full flex items-center">
      <div
        className={`group flex items-center rounded-md border text-sm transition-all ${
          isSelected
            ? "border-primary bg-primary/10 shadow-sm ring-1 ring-primary"
            : "border-input bg-background hover:bg-accent/50"
        }`}
      >
        <button
          type="button"
          onClick={onSelect}
          className="flex items-center gap-2 px-3 py-2 text-left"
          title={`View ${video.name} in central monitor`}
        >
          <FileVideo className={`size-4 shrink-0 ${isSelected ? "text-primary" : "text-muted-foreground"}`} />
          <span className="font-medium truncate max-w-[180px] sm:max-w-[240px]">{video.name}</span>
          <span className="shrink-0 text-xs text-muted-foreground">
            {(video.size / 1_000_000).toLocaleString("en-US", { maximumFractionDigits: 1 })} MB
          </span>
        </button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="h-8 px-1.5 text-muted-foreground hover:text-foreground"
              aria-label={`More options for ${video.name}`}
            >
              <MoreVertical className="size-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {canEdit && (
              <DropdownMenuItem className="flex justify-between" onSelect={handleTrimClick}>
                <span>Trim Video</span>
                <Scissors className="size-4" />
              </DropdownMenuItem>
            )}
            {canEdit && (
              <DropdownMenuItem className="flex justify-between" onSelect={() => setRemoveSegmentOpen(true)}>
                <span>Remove Segment</span>
                <Scissors className="size-4 text-destructive" />
              </DropdownMenuItem>
            )}
            <DropdownMenuItem className="flex justify-between" disabled={downloadVideo.isPending} onSelect={download}>
              <span>Download</span>
              <Download className="size-4" />
            </DropdownMenuItem>
            {canEdit && (
              <DropdownMenuItem className="flex justify-between text-destructive" onSelect={() => setConfirmOpen(true)}>
                <span>Delete</span>
                <Trash className="size-4" />
              </DropdownMenuItem>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <TrimVideoDialog
        open={trimOpen}
        onOpenChange={setTrimOpen}
        video={video}
        ownerId={ownerId}
        projectId={pid}
        token={session.token}
        shareId={shareId}
        allowFast={session.user.type === "premium"}
      />
      <RemoveSegmentVideoDialog
        open={removeSegmentOpen}
        onOpenChange={setRemoveSegmentOpen}
        video={video}
        ownerId={ownerId}
        projectId={pid}
        projectVersion={version}
        token={session.token}
        shareId={shareId}
      />
      <Dialog
        open={confirmOpen}
        onOpenChange={(next) => {
          if (!deleteVideo.isPending) setConfirmOpen(next);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Are you sure?</DialogTitle>
            <DialogDescription>This action cannot be undone.</DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setConfirmOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" disabled={deleteVideo.isPending} onClick={confirmDelete}>
              {deleteVideo.isPending ? "Deleting..." : "Permanently Delete"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </li>
  );
}