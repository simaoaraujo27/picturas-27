"use client";

import { Download, Film, Image as ImageIcon, LoaderCircle, OctagonAlert, Play } from "lucide-react";
import { fetchSharedProject, resolveShareLink, getTrimProjectVideoStatus } from "@/lib/projects";
import { ProjectImageList } from "@/components/project-page/project-image-list";
import { VideoWorkspace } from "@/components/project-page/video-workspace";
import { TrimVideoDialog } from "@/components/project-page/trim-video-dialog";
import { SpeedVideoDialog } from "@/components/project-page/speed-video-dialog";
import { RemoveSegmentVideoDialog } from "@/components/project-page/remove-segment-video-dialog";
import { ViewToggle } from "@/components/project-page/view-toggle";
import { AddImagesDialog } from "@/components/project-page/add-images-dialog";
import { AddVideoDialog } from "@/components/project-page/add-video-dialog";
import { CompileVideosDialog } from "@/components/project-page/compile-videos-dialog";
import { Button } from "@/components/ui/button";
import { Toolbar } from "@/components/toolbar/toolbar";
import { ShareProjectDialog } from "@/components/projects/share-dialog";
import {
  useGetProject,
  useGetProjectResults,
  useGetSocket,
} from "@/lib/queries/projects";
import Loading from "@/components/loading";
import { ProjectProvider } from "@/providers/project-provider";
import { use, useEffect, useLayoutEffect, useMemo, useState, useRef } from "react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useSession } from "@/providers/session-provider";
import {
  useDownloadProject,
  useDownloadProjectResults,
  useProcessProject,
  useCancelProjectProcess,
  useDownloadProjectPdf,
  useTrimProjectVideo,
  useCancelTrimProjectVideo,         
} from "@/lib/mutations/projects";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu"; // shadcn / radix menu
import { useToast } from "@/hooks/use-toast";
import { ProjectImage, ProjectVideo } from "@/lib/projects";
import { Progress } from "@/components/ui/progress";
import { Card } from "@/components/ui/card";
import { Transition } from "@headlessui/react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useQueryClient } from "@tanstack/react-query";
import { ModeToggle } from "@/components/project-page/mode-toggle";
import { SidebarTrigger, useSidebar } from "@/components/ui/sidebar";
import { useIsMobile } from "@/hooks/use-mobile";
import { useUpdateSession } from "@/lib/mutations/session";
import { getErrorMessage } from "@/lib/error-messages";
import { PresetsDialog } from "@/components/presets/presets-dialog";
import { AiAssistantDialog } from "@/components/assistant/ai-assistant-dialog";

export default function Project({
  params,
}: {
  params: Promise<{ pid: string }>;
}) {
  const resolvedParams = use(params);
  const session = useSession();
  const { pid } = resolvedParams;
  const { toast } = useToast();
  const socket = useGetSocket(session.token);
  const updateSession = useUpdateSession();
  const searchParams = useSearchParams();
  const view = searchParams.get("view") ?? "grid";
  const mode = searchParams.get("mode") ?? "edit";
  // se vier ?owner=... usamos esse userId, senão usamos o próprio utilizador (owner normal)
  const ownerId = searchParams.get("owner") ?? session.user._id;
  const shareId = searchParams.get("share") ?? undefined;
  const project = useGetProject(session.user._id, pid, session.token, ownerId, shareId);
  const downloadProjectImages = useDownloadProject();
  const processProject = useProcessProject(
    session.user._id,
    pid,
    session.token,
    ownerId,
    shareId,
  );
  const cancelProcess = useCancelProjectProcess(
    session.user._id,
    pid,
    session.token,
    ownerId,
    shareId,
  );
  const trimProjectVideo = useTrimProjectVideo(
    session.user._id,
    pid,
    session.token,
    ownerId,
    shareId,
  );
  const cancelTrimVideo = useCancelTrimProjectVideo(
    session.user._id,
    pid,
    session.token,
    ownerId,
    shareId,
  );
  const activeTrimJobIdRef = useRef<string | null>(null);
  const [pendingVideoTrim, setPendingVideoTrim] = useState<{
    videoId: string;
    startTime: number;
    endTime: number;
    fastTrim?: boolean;
  } | null>(null);
  const downloadProjectResults = useDownloadProjectResults();
  const downloadProjectPdf = useDownloadProjectPdf();
  const router = useRouter();
  const path = usePathname();
  const sidebar = useSidebar();
  const isMobile = useIsMobile();
  const [currentImage, setCurrentImage] = useState<ProjectImage | null>(null);
  const [selectedVideoId, setSelectedVideoId] = useState<string | null>(null);
  const mediaParam = searchParams.get("media");
  const videoIdParam = searchParams.get("videoId");
  const [localMediaTab, setLocalMediaTab] = useState<"images" | "videos">("images");

  // Determine active media tab based on URL param, available media types, or user selection
  const activeMediaTab = useMemo<"images" | "videos">(() => {
    if (mediaParam === "videos") return "videos";
    if (mediaParam === "images") return "images";
    const imgsCount = project.data?.imgs?.length ?? 0;
    const videosCount = project.data?.videos?.length ?? 0;
    if (imgsCount === 0 && videosCount > 0) return "videos";
    if (videosCount === 0 && imgsCount > 0) return "images";
    return localMediaTab;
  }, [mediaParam, project.data?.imgs?.length, project.data?.videos?.length, localMediaTab]);

  const setActiveMediaTab = (tab: "images" | "videos") => {
    setLocalMediaTab(tab);
    const params = new URLSearchParams(searchParams.toString());
    params.set("media", tab);
    router.replace(`?${params.toString()}`);
  };

  const [trimDialogOpen, setTrimDialogOpen] = useState<boolean>(false);
  const [videoToTrim, setVideoToTrim] = useState<ProjectVideo | null>(null);
  const [videoSelected, setVideoSelected] = useState(false);
  const [videoToChangeSpeed, setVideoToChangeSpeed] = useState<ProjectVideo | null>(null);
  const [videoToRemoveSegment, setVideoToRemoveSegment] = useState<ProjectVideo | null>(null);
  const [processing, setProcessing] = useState<boolean>(false);
  const [processingProgress, setProcessingProgress] = useState<number>(0);
  const [processingSteps, setProcessingSteps] = useState<number>(1);
  const [waitingForPreview, setWaitingForPreview] = useState<string>("");
  const [canEdit, setCanEdit] = useState(true);

  // Ordenar vídeos cronologicamente para estabelecer histórico de estados
  const sortedVideos = useMemo(() => {
    const list = [...(project.data?.videos ?? [])];
    return list.sort(
      (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime(),
    );
  }, [project.data?.videos]);

  const prevVideosCountRef = useRef<number>(0);

  // Sincronizar vídeo selecionado pelo URL ou pelo estado mais recente
  useEffect(() => {
    if (videoIdParam && sortedVideos.some((v) => (v.id || (v as any)._id) === videoIdParam)) {
      setSelectedVideoId(videoIdParam);
    }
  }, [videoIdParam, sortedVideos]);

  useEffect(() => {
    if (sortedVideos.length > 0) {
      if (
        !selectedVideoId ||
        !sortedVideos.some((v) => (v.id || (v as any)._id) === selectedVideoId) ||
        sortedVideos.length > prevVideosCountRef.current
      ) {
        const last = sortedVideos[sortedVideos.length - 1];
        setSelectedVideoId(last.id || (last as any)._id);
      }
    } else {
      setSelectedVideoId(null);
    }
    prevVideosCountRef.current = sortedVideos.length;
  }, [sortedVideos, selectedVideoId]);

  const currentVideo =
    sortedVideos.find((v) => (v.id || (v as any)._id) === selectedVideoId) ??
    sortedVideos[sortedVideos.length - 1] ??
    null;

  // Histórico de versões (linhagem) específico do vídeo atual
  const currentVideoHistory = useMemo(() => {
    if (!currentVideo || sortedVideos.length === 0) return [];
    const videoMap = new Map<string, ProjectVideo>();
    sortedVideos.forEach((v) => {
      const vid = v.id || (v as any)._id;
      if (vid) videoMap.set(String(vid), v);
    });

    const currentVid = String(currentVideo.id || (currentVideo as any)._id);
    let root = currentVideo;
    const visited = new Set<string>([currentVid]);
    while (root.sourceVideoId && videoMap.has(String(root.sourceVideoId))) {
      const parent = videoMap.get(String(root.sourceVideoId))!;
      const parentId = String(parent.id || (parent as any)._id);
      if (visited.has(parentId)) break;
      visited.add(parentId);
      root = parent;
    }

    const lineage: ProjectVideo[] = [root];
    let curr = root;
    const lineageVisited = new Set<string>([String(root.id || (root as any)._id)]);
    while (true) {
      const currId = String(curr.id || (curr as any)._id);
      const child = sortedVideos.find((v) => String(v.sourceVideoId) === currId);
      if (!child) break;
      const childId = String(child.id || (child as any)._id);
      if (lineageVisited.has(childId)) break;
      lineageVisited.add(childId);
      lineage.push(child);
      curr = child;
    }
    return lineage;
  }, [currentVideo, sortedVideos]);

  const currentVideoHistoryIndex = currentVideo
    ? currentVideoHistory.findIndex(
        (v) => (v.id || (v as any)._id) === (currentVideo.id || (currentVideo as any)._id)
      )
    : -1;

  const canUndoVideo = currentVideoHistoryIndex > 0;
  const canRedoVideo =
    currentVideoHistoryIndex >= 0 && currentVideoHistoryIndex < currentVideoHistory.length - 1;

  const handleUndoVideo = () => {
    if (canUndoVideo) {
      const prev = currentVideoHistory[currentVideoHistoryIndex - 1];
      const vid = prev.id || (prev as any)._id;
      setSelectedVideoId(vid);
      const params = new URLSearchParams(searchParams.toString());
      params.set("videoId", vid);
      router.replace(`?${params.toString()}`);
    }
  };

  const handleRedoVideo = () => {
    if (canRedoVideo) {
      const next = currentVideoHistory[currentVideoHistoryIndex + 1];
      const vid = next.id || (next as any)._id;
      setSelectedVideoId(vid);
      const params = new URLSearchParams(searchParams.toString());
      params.set("videoId", vid);
      router.replace(`?${params.toString()}`);
    }
  };

  // estado para saber se o link de partilha foi revogado
  const [shareRevoked, setShareRevoked] = useState(false);

  // flag para ignorar updates depois de cancelar
  const ignoreUpdatesRef = useRef(false);

  // início do processamento
  const processStartTimeRef = useRef<number | null>(null);

  // se um processamento envolve ferramentas de IA ou não
  const processIsAiRef = useRef<boolean>(false);

  const totalProcessingSteps =
    (project.data?.tools.length ?? 0) * (currentImage ? 1 : (project.data?.imgs.length ?? 0));
  const projectResults = useGetProjectResults(
    session.user._id,
    pid,
    session.token,
    ownerId,
    shareId,
  );
  const qc = useQueryClient();

  useLayoutEffect(() => {
    if (
      !["edit", "results"].includes(mode) ||
      !["grid", "carousel"].includes(view)
    ) {
      router.replace(path);
    }
  }, [mode, view, path, router, projectResults.data]);

  useEffect(() => {
  let cancelled = false;

  async function loadSharePermission() {
    if (!shareId) {
      setCanEdit(true);
      return;
    }

    try {
      const info = await resolveShareLink(shareId);
      // ajusta o campo conforme o teu backend devolve
      // exemplos comuns: info.permission === "edit" | "read"
      const perm = (info as any)?.permission ?? (info as any)?.access ?? (info as any)?.mode;

      const editable = perm === "edit" || perm === "write";
      if (!cancelled) setCanEdit(editable);
    } catch (err: any) {
      // se falhar, joga pelo seguro: read-only
      if (!cancelled) setCanEdit(false);
    }
  }

  loadSharePermission();

  return () => {
    cancelled = true;
  };
}, [shareId]);

  // link de partilha enquanto o editor está aberto em modo "edit"
  useEffect(() => {
    if (mode !== "edit") return;
    if (!shareId) return;
    if (!session.token) return;

    const sid = shareId;          // ← narrowing definitivo
    const token = session.token;

    let cancelled = false;

    async function pingShare() {
      try {
        await resolveShareLink(shareId!);
        setShareRevoked(false);
      } catch (err: any) {
        const status = err?.response?.status;
        // 410 = revogado → true
        if (status === 410) setShareRevoked(true);
        // outros erros: podes decidir
        else setShareRevoked(true); // ou false se preferires "falha de rede não revoga"
      }
    }

    pingShare();

    const interval = setInterval(pingShare, 10000);

    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [mode, shareId, session.token]);

  // heartbeat de presença (editores ativos) enquanto estiver em mode=edit
  useEffect(() => {
    if (mode !== "edit") return;
    if (!canEdit) return;

    let cancelled = false;

    const qs = new URLSearchParams();
    if (ownerId) qs.set("owner", ownerId);
    if (shareId) qs.set("share", shareId);

  const baseUrl = `/api-gateway/projects/${session.user._id}/${pid}/presence?${qs.toString()}`;

    async function pingPresence() {
      try {
        await fetch(baseUrl, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${session.token}`,
          },
        });
      } catch {
        // ignora (o erro “a sério” aparece quando se tenta carregar o projeto)
      }
    }

    // ping inicial
    pingPresence();

    // ping periódico
    const interval = setInterval(() => {
      if (!cancelled) pingPresence();
    }, 5000);

    return () => {
      cancelled = true;
      clearInterval(interval);

      // libertar slot (best-effort)
      fetch(baseUrl, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${session.token}` },
      }).catch(() => {});
    };
  }, [mode, pid, ownerId, shareId, session.token, session.user._id, canEdit]);

useEffect(() => {
  if (!socket.data) return;

  // entrar na room do projeto
  socket.data.emit("join-project", pid);

  const onProjectUpdated = (evt: { projectId: string; version?: number }) => {
    if (!evt || evt.projectId !== pid) return;

    // 1) refetch do projeto
    qc.invalidateQueries({
      queryKey: ["project", session.user._id, pid, session.token, ownerId, shareId],
      refetchType: "all",
    });

    // 2) imagens e results (se a alteração pode impactar)
    qc.invalidateQueries({
      queryKey: ["projectImages", session.user._id, pid, session.token, ownerId, shareId],
      refetchType: "all",
    });
    qc.invalidateQueries({
      queryKey: ["projectResults", session.user._id, pid, session.token, ownerId, shareId],
      refetchType: "all",
    });

    toast({
      title: "Project updated",
      description: "The project was modified by another user. Updated to the latest version.",
    });
  };

  socket.data.on("project-updated", onProjectUpdated);

    return () => {
      socket.data.off("project-updated", onProjectUpdated);
      socket.data.emit("leave-project", pid);
    };
  }, [socket.data, pid, qc, session.user._id, session.token, ownerId, shareId, toast]);

  useEffect(() => {
    if (!socket.data) return;

    const onProjectOp = (payload: { projectId: string; op: any }) => {
      if (!payload || payload.projectId !== pid) return;
      const op = payload.op;
      if (!op) return;

      if (op.type === "video-trim-progress") {
        if (activeTrimJobIdRef.current && op.jobId === activeTrimJobIdRef.current) {
          setProcessing(true);
          setProcessingProgress(op.progress || 0);
        }
      } else if (op.type === "video-trim-completed") {
        if (activeTrimJobIdRef.current && op.jobId === activeTrimJobIdRef.current) {
          activeTrimJobIdRef.current = null;
          setProcessing(false);
          setProcessingProgress(0);
          setPendingVideoTrim(null);
          qc.invalidateQueries({ queryKey: ["project", session.user._id, pid], exact: false });
          qc.invalidateQueries({ queryKey: ["videoStorage", session.user._id], exact: false });
          updateSession.mutate({ userId: session.user._id, token: session.token });
          const newVid = op.video?.id || op.video?._id;
          if (newVid) {
            setSelectedVideoId(String(newVid));
            const params = new URLSearchParams(searchParams.toString());
            params.set("videoId", String(newVid));
            params.set("media", "videos");
            router.replace(`?${params.toString()}`);
          }
          toast({
            title: "Video trimmed",
            description: `Video "${op.video?.name || "trimmed"}" created successfully.`,
          });
        }
      } else if (op.type === "video-trim-error") {
        if (activeTrimJobIdRef.current && op.jobId === activeTrimJobIdRef.current) {
          activeTrimJobIdRef.current = null;
          setProcessing(false);
          setProcessingProgress(0);
          qc.invalidateQueries({ queryKey: ["project", session.user._id, pid], exact: false });
          qc.invalidateQueries({ queryKey: ["videoStorage", session.user._id], exact: false });
          updateSession.mutate({ userId: session.user._id, token: session.token });
          toast({
            title: "Trim failed",
            description: op.error || "Could not process video trim.",
            variant: "destructive",
          });
        }
      } else if (op.type === "video-trim-cancelled") {
        if (activeTrimJobIdRef.current && op.jobId === activeTrimJobIdRef.current) {
          activeTrimJobIdRef.current = null;
          setProcessing(false);
          setProcessingProgress(0);
          setPendingVideoTrim(null);
          qc.invalidateQueries({ queryKey: ["project", session.user._id, pid], exact: false });
          qc.invalidateQueries({ queryKey: ["videoStorage", session.user._id], exact: false });
          updateSession.mutate({ userId: session.user._id, token: session.token });
          toast({
            title: "Trim cancelled",
            description: "Video trim was cancelled and any debited operations were refunded.",
          });
        }
      } else if (op.type === "video-compile-completed") {
      qc.invalidateQueries({ queryKey: ["project", session.user._id, pid], exact: false });
      qc.invalidateQueries({ queryKey: ["videoStorage", session.user._id], exact: false });
      updateSession.mutate({ userId: session.user._id, token: session.token });
      toast({
        title: "Videos compiled",
        description: `Video "${op.video?.name || "compilation"}" created successfully.`,
      });
     }
    };

    socket.data.on("project-op", onProjectOp);
    return () => {
      socket.data.off("project-op", onProjectOp);
    };
  }, [socket.data, pid, qc, session.user._id, session.token, searchParams, router, updateSession, toast]);

  // Fallback polling for video trim in case websocket event is missed
  useEffect(() => {
    if (!processing || !activeTrimJobIdRef.current) return;
    const interval = setInterval(async () => {
      const currentJobId = activeTrimJobIdRef.current;
      if (!currentJobId) return;
      try {
        const job = await getTrimProjectVideoStatus({
          uid: session.user._id,
          pid,
          jobId: currentJobId,
          token: session.token,
          ownerId: ownerId ?? undefined,
          shareId: shareId ?? undefined,
        });
        if (currentJobId !== activeTrimJobIdRef.current) return;
        if (job.status === "completed") {
          activeTrimJobIdRef.current = null;
          setProcessing(false);
          setProcessingProgress(0);
          setPendingVideoTrim(null);
          qc.invalidateQueries({ queryKey: ["project", session.user._id, pid], exact: false });
          qc.invalidateQueries({ queryKey: ["videoStorage", session.user._id], exact: false });
          updateSession.mutate({ userId: session.user._id, token: session.token });
          const newVid = job.newVideoId;
          if (newVid) {
            setSelectedVideoId(String(newVid));
            const params = new URLSearchParams(searchParams.toString());
            params.set("videoId", String(newVid));
            params.set("media", "videos");
            router.replace(`?${params.toString()}`);
          }
          toast({
            title: "Video trimmed",
            description: `Video "${job.newVideoName || "trimmed"}" created successfully.`,
          });
        } else if (job.status === "failed") {
          activeTrimJobIdRef.current = null;
          setProcessing(false);
          setProcessingProgress(0);
          qc.invalidateQueries({ queryKey: ["project", session.user._id, pid], exact: false });
          qc.invalidateQueries({ queryKey: ["videoStorage", session.user._id], exact: false });
          updateSession.mutate({ userId: session.user._id, token: session.token });
          toast({
            title: "Trim failed",
            description: job.error || "Could not process video trim.",
            variant: "destructive",
          });
        } else if (job.status === "cancelled") {
          activeTrimJobIdRef.current = null;
          setProcessing(false);
          setProcessingProgress(0);
          setPendingVideoTrim(null);
          qc.invalidateQueries({ queryKey: ["project", session.user._id, pid], exact: false });
          qc.invalidateQueries({ queryKey: ["videoStorage", session.user._id], exact: false });
          updateSession.mutate({ userId: session.user._id, token: session.token });
          toast({
            title: "Trim cancelled",
            description: "Video trim was cancelled and any debited operations were refunded.",
          });
        } else if (typeof job.progress === "number" && job.progress > 0) {
          setProcessingProgress((prev) => Math.max(prev, job.progress));
        }
      } catch (err) {
        // Polling error ignored
      }
    }, 2000);
    return () => clearInterval(interval);
  }, [processing, pid, qc, session.user._id, session.token, ownerId, shareId, searchParams, router, updateSession, toast]);

  useEffect(() => {
  function onProcessUpdate(msgId: string) {
    // se já cancelámos ou já não estamos em processamento, ignora tudo
    if (ignoreUpdatesRef.current || !processing) return;

    setProcessingSteps((prev) => {
      const nextSteps = prev + 1;

      const progress =
        totalProcessingSteps > 0
          ? Math.min(Math.round((nextSteps * 100) / totalProcessingSteps), 100)
          : 100;

      setProcessingProgress(progress);

      if (nextSteps >= totalProcessingSteps) {
        setTimeout(() => {
          if (ignoreUpdatesRef.current) {
            // cancelar medição
            processStartTimeRef.current = null;
            processIsAiRef.current = false;
            return;
          }

          const startedAt = processStartTimeRef.current;
          const isAiProcess = processIsAiRef.current;

          // limpar medição
          processStartTimeRef.current = null;
          processIsAiRef.current = false;

          projectResults.refetch().then(() => {
            if (ignoreUpdatesRef.current) return;

            setProcessing(false);
            if (!isMobile) sidebar.setOpen(true);
            setProcessingProgress(0);
            setProcessingSteps(1);

            // avisar o ProjectProvider que o Apply terminou
            setWaitingForPreview("__APPLY_DONE__");

            const params = new URLSearchParams();
            params.set("mode", "results");
            params.set("view", "grid");
            
            const ownerFromQuery = searchParams.get("owner");
            const shareFromQuery = searchParams.get("share");  

            if (ownerFromQuery) params.set("owner", ownerFromQuery);
            if (shareFromQuery) params.set("share", shareFromQuery); 

            router.push(`?${params.toString()}`);

            if (startedAt != null) {
              const durationMs = performance.now() - startedAt;
              const seconds = durationMs / 1000;
              const perStep =
                totalProcessingSteps > 0
                  ? durationMs / totalProcessingSteps
                  : undefined;

              console.log(
                `[Perf] Processing ${
                  isAiProcess ? "AI" : "standard"
                } completed in ${seconds.toFixed(2)}s (${totalProcessingSteps} steps${
                  perStep ? ` ~${perStep.toFixed(0)}ms/step` : ""
                })`,
              );

              // limiares diferentes: 5s filtros normais, 60s IA
              const NORMAL_THRESHOLD_MS = 5000; // 5s
              const AI_THRESHOLD_MS = 60000; // 60s

              const threshold = isAiProcess
                ? AI_THRESHOLD_MS
                : NORMAL_THRESHOLD_MS;

              if (durationMs > threshold) {
                toast({
                  title: isAiProcess
                    ? "Slow AI processing"
                    : "Slow processing",
                  description: isAiProcess
                    ? `This processing with AI tools took ${seconds.toFixed(
                        1,
                      )} seconds. This is within the acceptable limit for AI (up to 1 minute), but was slower than expected.`
                    : `This processing took ${seconds.toFixed(
                        1,
                      )} seconds, above the 5-second target for standard filters.`,
                });
              }
            }
          });
        }, 2000);
      }

      return nextSteps;
    });
  }

  function onProcessError(payload: { error_code: string; error_msg: string }) {
    if (processStartTimeRef.current !== null) {
      const durationMs = performance.now() - processStartTimeRef.current;
      console.error(
        `[Perf] Processing ${
          processIsAiRef.current ? "AI" : "standard"
        } failed after ${(durationMs / 1000).toFixed(2)}s (code ${
          payload?.error_code ?? "N/A"
        })`,
      );
      processStartTimeRef.current = null;
      processIsAiRef.current = false;
    }

    console.error("process-error", payload);
    setProcessing(false);
    setProcessingProgress(0);
    setProcessingSteps(1);
    toast({
      title: "Processing failed",
      description:
        payload?.error_msg ||
        "An error occurred while processing the project. Please try again.",
      variant: "destructive",
    });
  }

  let active = true;

  if (active && socket.data) {
    socket.data.on("process-update", onProcessUpdate);
    socket.data.on("process-error", onProcessError);
  }

  return () => {
    active = false;
    if (socket.data) {
      socket.data.off("process-update", onProcessUpdate);
      socket.data.off("process-error", onProcessError);
    }
  };
}, [
  pid,
  qc,
  router,
  session.token,
  session.user._id,
  socket.data,
  totalProcessingSteps,
  sidebar,
  isMobile,
  projectResults,
  toast,
  processing,
]);

if (project.isError) {
  // caso especial: projeto aberto via link de partilha
  if (shareId) {
    // tenta extrair o status do erro (React Query + Axios)
    const status =
      (project.error as any)?.response?.status ??
      (project.error as any)?.status;

    const data = (project.error as any)?.response?.data;

    // 429 = limite de editores ativos
    if (status === 429) {
      const active = data?.active;
      const limit = data?.limit;

      return (
        <div className="flex size-full justify-center items-center h-screen p-8">
          <Alert variant="destructive" className="w-fit max-w-[40rem] text-wrap truncate">
            <OctagonAlert className="size-4" />
            <AlertTitle>Collaborator limit reached</AlertTitle>
            <AlertDescription>
              {typeof active === "number" && typeof limit === "number"
                ? `This project already has ${active}/${limit} active editors. Close a session or try again shortly.`
                : "This project has reached the maximum number of active editors. Close a session or try again shortly."}
            </AlertDescription>
          </Alert>
        </div>
      );
    }

    // 410 = revogado
    if (status === 410) {
      return (
        <div className="flex size-full justify-center items-center h-screen p-8">
          <Alert variant="destructive" className="w-fit max-w-[40rem] text-wrap truncate">
            <OctagonAlert className="size-4" />
            <AlertTitle>Share link revoked</AlertTitle>
            <AlertDescription>
              This share link is no longer valid. The owner has revoked access to this project.
            </AlertDescription>
          </Alert>
        </div>
      );
    }

    // 404 = link inválido / não existe
    if (status === 404) {
      return (
        <div className="flex size-full justify-center items-center h-screen p-8">
          <Alert variant="destructive" className="w-fit max-w-[40rem] text-wrap truncate">
            <OctagonAlert className="size-4" />
            <AlertTitle>Invalid share link</AlertTitle>
            <AlertDescription>
              This link does not exist or the project is no longer available.
            </AlertDescription>
          </Alert>
        </div>
      );
    }

    // fallback para outros erros quando há shareId
    return (
      <div className="flex size-full justify-center items-center h-screen p-8">
        <Alert variant="destructive" className="w-fit max-w-[40rem] text-wrap truncate">
          <OctagonAlert className="size-4" />
          <AlertTitle>Error opening project</AlertTitle>
          <AlertDescription>
            An error occurred while opening this shared project. Please try again.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  // comportamento normal para projetos do próprio utilizador
  const { title, description } = getErrorMessage("project-load", project.error);

  return (
    <div className="flex size-full justify-center items-center h-screen p-8">
      <Alert variant="destructive" className="w-fit max-w-[40rem] text-wrap truncate">
        <OctagonAlert className="size-4" />
        <AlertTitle>{title}</AlertTitle>
        <AlertDescription>{description}</AlertDescription>
      </Alert>
    </div>
  );
}

  if (
    project.isLoading ||
    !project.data ||
    projectResults.isLoading ||
    !projectResults.data
  )
    return (
      <div className="flex justify-center items-center h-screen">
        <Loading />
      </div>
    );

const handleCancel = () => {
  // Se houver um job de vídeo ativo, cancelar o job de vídeo
  if (activeTrimJobIdRef.current) {
    const jobId = activeTrimJobIdRef.current;
    activeTrimJobIdRef.current = null;
    setProcessing(false);
    setProcessingProgress(0);
    setPendingVideoTrim(null);
    cancelTrimVideo.mutate(
      { jobId, projectVersion: project.data?.version },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: ["project", session.user._id, pid], exact: false });
          qc.invalidateQueries({ queryKey: ["videoStorage", session.user._id], exact: false });
          updateSession.mutate({ userId: session.user._id, token: session.token });
          toast({
            title: "Trim cancelled",
            description: "Video trim processing was cancelled and operations were refunded.",
          });
        },
        onError: (err) => {
          console.error("Failed to cancel trim job:", err);
        },
      }
    );
    return;
  }

  // ignorar updates vindos do socket
  ignoreUpdatesRef.current = true;

  // cancelar medição de tempo e tipo
  processStartTimeRef.current = null;
  processIsAiRef.current = false;

  // parar tudo no UI
  setProcessing(false);
  setProcessingProgress(0);
  setProcessingSteps(1);

  // reabrir a sidebar em desktop 
  if (!isMobile) {
    sidebar.setOpen(true);
  }

  // limpar estado de preview (se alguma tool estava a fazer preview)
  setWaitingForPreview("");

  // cancelar no backend
  cancelProcess.mutate(
    {
      projectVersion: project.data.version
    },
    {
      onSuccess: () => {

      qc.invalidateQueries({
        queryKey: ["projectImages", session.user._id, pid, session.token, ownerId, shareId],
        refetchType: "all",
      });

        // voltar a ir buscar a sessão para atualizar remaining_operations
        updateSession.mutate({
          userId: session.user._id,
          token: session.token,
        });

        toast({
          title: "Processing cancelled",
          description:
            "Project processing was cancelled. You can adjust your tools and try again.",
        });
      },
      
      onError: (error) => {
        const { title, description } = getErrorMessage(
          "project-cancel-process",
          error,
        );
        toast({
          title,
          description,
          variant: "destructive",
        });
      },
    },
  );
};
  
  return (
    <ProjectProvider
      project={project.data}
      currentImage={currentImage}
      preview={{ waiting: waitingForPreview, setWaiting: setWaitingForPreview }}
      ownerId={ownerId}
      shareId={shareId}
      canEdit={canEdit}
    >
      <div className="flex flex-col h-screen relative">
        {/* Warning banner when shared link is revoked */}
        {shareId && shareRevoked && (
          <div className="w-full border-b border-destructive bg-destructive/10 text-destructive text-sm px-4 py-2 text-center">
            The owner has revoked the link. You can no longer edit this project.
          </div>
        )}

        {/* Header */}
        <div className="flex flex-col xl:flex-row justify-center items-start xl:items-center xl:justify-between border-b border-sidebar-border py-2 px-2 md:px-3 xl:px-4 h-fit gap-2">
          <div className="flex items-center justify-between w-full xl:w-auto gap-2">
            <h1 className="text-lg font-semibold truncate">
              {project.data.name}
            </h1>
            <div className="flex items-center gap-2 xl:hidden">
              <ViewToggle />
              <ModeToggle />
            </div>
          </div>
          <div className="flex items-center justify-between w-full xl:w-auto gap-2">
            <SidebarTrigger variant="outline" className="h-9 w-10 lg:hidden" />
                      <div className="flex items-center gap-2 flex-wrap justify-end xl:justify-normal w-full xl:w-auto">
              {mode !== "results" && (
                <>
                  <Button
                    disabled={
                      !canEdit ||
                      (activeMediaTab === "videos"
                        ? !pendingVideoTrim || trimProjectVideo.isPending
                        : (project.data.tools.length <= 0 || waitingForPreview !== "" || processing))
                    }
                    className="inline-flex gap-1.5"
                    onClick={() => {
                      if (activeMediaTab === "videos") {
                        if (!pendingVideoTrim) return;
                        trimProjectVideo.mutate(
                          {
                            videoId: pendingVideoTrim.videoId,
                            startTime: pendingVideoTrim.startTime,
                            endTime: pendingVideoTrim.endTime,
                            fastTrim: pendingVideoTrim.fastTrim,
                            projectVersion: project.data?.version ?? 0,
                          },
                          {
                            onSuccess: (res: any) => {
                              setPendingVideoTrim(null);
                              updateSession.mutate({ userId: session.user._id, token: session.token });
                              const jobId = res?.jobId || res?.id || res?.messageId || res?.data?.jobId || res?.data?.id || res?.data?.messageId;
                              if (jobId) {
                                activeTrimJobIdRef.current = jobId;
                                setProcessing(true);
                                setProcessingProgress(5);
                                toast({
                                  title: "Trim in progress",
                                  description: "Task queued in the worker. Tracking progress in real time...",
                                });
                              } else {
                                toast({
                                  title: "Video trim queued",
                                  description: "The video is being processed in the background.",
                                });
                              }
                            },
                            onError: (error) => {
                              const { title, description } = getErrorMessage(
                                "video-trim",
                                error,
                              );
                              toast({
                                title,
                                description,
                                variant: "destructive",
                              });
                            },
                          },
                        );
                        return;
                      }

                      // começa a contar o tempo
                      processStartTimeRef.current = performance.now();
                      setProcessing(true);        
                      sidebar.setOpen(false);
                      
                      const aiProcedures = [
                        "bg_remove_ai",
                        "cut_ai",
                        "obj_ai",
                        "people_ai",
                        "text_ai",
                        "upgrade_ai",
                        "expand_ai",
                      ];

                      processIsAiRef.current = project.data.tools.some((t) =>
                        aiProcedures.includes(t.procedure),
                      );

                      processProject.mutate(
                        {
                          projectVersion: project.data.version,
                          imgId: currentImage?._id,
                        },
                        {
                          onSuccess: () => {
                            ignoreUpdatesRef.current = false;
                            setProcessing(true);
                            sidebar.setOpen(false);

                            updateSession.mutate({
                              userId: session.user._id,
                              token: session.token,
                            });
                          },
                          onError: (error: unknown) => {
                            if (processStartTimeRef.current !== null) {
                              const durationMs =
                                performance.now() - processStartTimeRef.current;
                              console.error(
                                `[Perf] Processing ${
                                  processIsAiRef.current ? "AI" : "standard"
                                } failed at startup after ${
                                  (durationMs / 1000).toFixed(2)
                                }s`,
                              );
                              processStartTimeRef.current = null;
                              processIsAiRef.current = false;
                            }

                            const { title, description } = getErrorMessage(
                              "project-process",
                              error,
                            );
                            toast({
                              title,
                              description,
                              variant: "destructive",
                            });
                          },
                        },
                      );
                    }}
                  >
                    {activeMediaTab === "videos" && trimProjectVideo.isPending ? (
                      <LoaderCircle className="size-4 animate-spin" />
                    ) : (
                      <Play className="size-4" />
                    )}
                    <span>Apply</span>
                  </Button>

          {canEdit && (
            <>
                  <AiAssistantDialog
                    uid={session.user._id}
                    pid={pid}
                    token={session.token}
                    ownerId={ownerId}
                    shareId={shareId}
                    projectVersion={project.data.version}
                    currentTools={project.data.tools}
                    currentImgId={currentImage?._id}   
                  />

                  <PresetsDialog />
                  <AddImagesDialog />
                  <AddVideoDialog />
                  <CompileVideosDialog videos={project.data.videos ?? []} />
          </>
          )}
                {/* botão Share só para o owner */}
                {session.user._id === ownerId && (
                  <ShareProjectDialog 
                  projectId={project.data._id} 
                  projectVersion={project.data.version}
                />
                )}
                </>
              )}

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="outline"
                    className="px-3"
                    title="Download project"
                    disabled={
                      downloadProjectImages.isPending ||
                      downloadProjectResults.isPending ||
                      downloadProjectPdf.isPending
                    }
                  >
                    {downloadProjectImages.isPending ||
                    downloadProjectResults.isPending ||
                    downloadProjectPdf.isPending ? (
                      <LoaderCircle className="animate-spin" />
                    ) : (
                      <Download />
                    )}
                        </Button>
                      </DropdownMenuTrigger>

                      <DropdownMenuContent align="end">
                        <DropdownMenuItem
                          onClick={() => {
                            (mode === "edit"
                              ? downloadProjectImages
                              : downloadProjectResults
                            ).mutate(
                              {
                                uid: session.user._id,
                                pid: project.data._id,
                                token: session.token,
                                projectName: project.data.name,
                                ownerId,
                                shareId,
                              },
                              {
                                onSuccess: () => {
                                  toast({
                                    title:
                                      mode === "edit"
                                        ? `Project ${project.data.name} downloaded as ZIP.`
                                        : `Results for ${project.data.name} downloaded as ZIP.`,
                                  });
                                },
                              },
                            );
                          }}
                          disabled={
                            downloadProjectImages.isPending || downloadProjectResults.isPending
                          }
                        >
                          {mode === "edit"
                            ? "Download images (ZIP)"
                            : "Download results (ZIP)"}
                        </DropdownMenuItem>

                          <DropdownMenuItem
                            onClick={() => {
                              downloadProjectPdf.mutate(
                                {
                                  uid: session.user._id,
                                  pid: project.data._id,
                                  token: session.token,
                                  ownerId,
                                  shareId,
                                  // em results queremos as EDITADAS, em edit queremos as originais
                                  useResults: mode === "results",
                                },
                                {
                                  onSuccess: () => {
                                    toast({
                                      title:
                                        mode === "results"
                                          ? `Results for ${project.data.name} downloaded as PDF.`
                                          : `Project ${project.data.name} downloaded as PDF.`,
                                    });
                                  },
                                },
                              );
                            }}
                            disabled={downloadProjectPdf.isPending}
                          >
                            {mode === "results"
                              ? "Download results (PDF)"
                              : "Download images (PDF)"}
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>

              {(project.data?.videos?.length ?? 0) > 0 &&
                (project.data?.imgs?.length ?? 0) > 0 && (
                  <div className="flex items-center rounded-lg border bg-muted/40 p-0.5 mr-2">
                    <Button
                      size="sm"
                      variant={activeMediaTab === "images" ? "secondary" : "ghost"}
                      className="h-7 px-2.5 text-xs gap-1.5"
                      onClick={() => setActiveMediaTab("images")}
                    >
                      <ImageIcon className="size-3.5" />
                      <span>Images ({project.data?.imgs?.length})</span>
                    </Button>
                    <Button
                      size="sm"
                      variant={activeMediaTab === "videos" ? "secondary" : "ghost"}
                      className="h-7 px-2.5 text-xs gap-1.5"
                      onClick={() => setActiveMediaTab("videos")}
                    >
                      <Film className="size-3.5" />
                      <span>Videos ({project.data?.videos?.length})</span>
                    </Button>
                  </div>
                )}
              <ViewToggle />
              <ModeToggle />
            </div>
          </div>
        </div>
      {/* Main Content */}

      <div className="h-full min-h-0 overflow-x-hidden flex flex-col">
        <div className="min-h-0 flex flex-1">
          {!(view === "grid" && activeMediaTab === "videos") && (
            <Toolbar
              activeMediaTab={activeMediaTab}
              onTrimVideo={() => {
                if (currentVideo) {
                  setVideoToTrim(currentVideo);
                  setTrimDialogOpen(true);
                }
              }}
              canEdit={canEdit}
              canUndo={canUndoVideo}
              canRedo={canRedoVideo}
              onUndo={handleUndoVideo}
              onRedo={handleRedoVideo}
              videoSelected={videoSelected}
              onChangeVideoSpeed={canEdit && currentVideo ? () => setVideoToChangeSpeed(currentVideo) : undefined}
              onRemoveSegment={canEdit && currentVideo ? () => setVideoToRemoveSegment(currentVideo) : undefined}
            />
          )}
          {view === "carousel" && activeMediaTab === "videos" && currentVideo ? (
            <VideoWorkspace
              video={currentVideo}
              videos={sortedVideos}
              projectId={pid}
              projectVersion={project.data?.version ?? 0}
              onChangeVideoSpeed={(v) => { if (canEdit) setVideoToChangeSpeed(v); }}
              onRemoveSegment={(v) => { if (canEdit) setVideoToRemoveSegment(v); }}
              pendingTrim={pendingVideoTrim}
              onCancelPendingTrim={() => setPendingVideoTrim(null)}
              onSelectVideo={(v) => {
                const vid = v.id || (v as any)._id;
                setSelectedVideoId(vid);
                setActiveMediaTab("videos");
                const params = new URLSearchParams(searchParams.toString());
                params.set("media", "videos");
                params.set("videoId", vid);
                router.replace(`?${params.toString()}`);
              }}
              onTrimVideo={(v) => {
                setVideoToTrim(v);
                setTrimDialogOpen(true);
              }}
              canEdit={canEdit}
              ownerId={ownerId}
              shareId={shareId}
              canUndo={canUndoVideo}
              canRedo={canRedoVideo}
              onUndo={handleUndoVideo}
              onRedo={handleRedoVideo}
              currentStateIndex={currentVideoHistoryIndex}
              totalStates={currentVideoHistory.length}
              onBackToGrid={() => {
                const params = new URLSearchParams(searchParams.toString());
                params.set("view", "grid");
                router.push(`?${params.toString()}`);
              }}
            />
          ) : (
            <ProjectImageList
              setCurrentImageId={(img) => {
                setCurrentImage(img);
                setActiveMediaTab("images");
              }}
              setVideoSelected={setVideoSelected}
              results={projectResults.data}
              videos={sortedVideos}
              onSelectVideo={(v) => {
                const vid = v.id || (v as any)._id;
                setSelectedVideoId(vid);
                setActiveMediaTab("videos");
                const params = new URLSearchParams(searchParams.toString());
                params.set("mode", mode);
                params.set("view", "carousel");
                params.set("media", "videos");
                if (vid) params.set("videoId", vid);
                router.push(`?${params.toString()}`);
              }}
              onTrimVideo={(v) => {
                setVideoToTrim(v);
                setTrimDialogOpen(true);
              }}
            />
          )}
        </div>
      </div>
      {videoToTrim && (
        <TrimVideoDialog
          video={videoToTrim}
          open={trimDialogOpen}
          onOpenChange={(next) => {
            setTrimDialogOpen(next);
            if (!next) setVideoToTrim(null);
          }}
          ownerId={ownerId}
          shareId={shareId}
          initialStartTime={
            pendingVideoTrim?.videoId === (videoToTrim.id || (videoToTrim as any)._id)
              ? pendingVideoTrim?.startTime
              : undefined
          }
          initialEndTime={
            pendingVideoTrim?.videoId === (videoToTrim.id || (videoToTrim as any)._id)
              ? pendingVideoTrim?.endTime
              : undefined
          }
          onConfirmRange={(range) => {
            setPendingVideoTrim(range);
            toast({
              title: "Trim range set",
              description: "Click 'Apply' in the top bar to process the video trim.",
            });
          }}
        />
      )}
      {videoToChangeSpeed && (
        <SpeedVideoDialog
          video={videoToChangeSpeed}
          open={true}
          onOpenChange={(next) => { if (!next) setVideoToChangeSpeed(null); }}
          ownerId={ownerId}
          shareId={shareId}
        />
      )}
      {videoToRemoveSegment && (
        <RemoveSegmentVideoDialog
          open={true}
          onOpenChange={(next) => { if (!next) setVideoToRemoveSegment(null); }}
          video={videoToRemoveSegment}
          ownerId={ownerId}
          projectId={pid}
          projectVersion={project.data?.version ?? 0}
          token={session.token}
          shareId={shareId}
        />
      )}
      <Transition
        show={processing}
        enter="transition-opacity ease-in duration-300"
        enterFrom="opacity-0"
        enterTo="opacity-100"
        leave="transition-opacity ease-out duration-300"
        leaveFrom="opacity-100"
        leaveTo="opacity-0"
      >
        <div className="absolute top-0 left-0 h-screen w-screen bg-black/70 z-50 flex justify-center items-center">
          <Card className="p-4 flex flex-col justify-center items-center gap-4">
            <div className="flex gap-2 items-center text-lg font-semibold">
              <h1>Processing</h1>
              <LoaderCircle className="size-[1em] animate-spin" />
            </div>
            <Progress value={processingProgress} className="w-96" />

            <Button
              variant="outline"
              disabled={cancelProcess.isPending}
              onClick={handleCancel}
            >
              {cancelProcess.isPending ? (
                <LoaderCircle className="size-[1em] animate-spin" />
              ) : (
                "Cancel"
              )}
            </Button>
          </Card>
        </div>
      </Transition>
      </div>
    </ProjectProvider>
  );
}
